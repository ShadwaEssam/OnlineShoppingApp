package com.example.se_commerce;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "customers.db";
    public static final String TABLE_NAME = "customers";
    public static final String COL_1 = "CustID"; //id
    public static final String COL_2 = "Username"; //username
    public static final String COL_3 = "CustName"; //password
    public static final String COL_4 = "Password";
    public static final String COL_5 = "cnf_pass";
    public static final String COL_6 = "Gender";
    public static final String COL_7 = "Birthdate";
    public static final String COL_8 = "Job";
    private static String databasename = "mydatabase";
    SQLiteDatabase mydatabase;


      /*sqLiteDatabase.execSQL("CREATE TABLE customers (CustID INTEGER PRIMARY KEY AUTOINCREMENT," +
                " username TEXT,password TEXT, cnf_pass text ,gender TEXT,birthday integer,job TEXT )"); */


    public DatabaseHelper(@Nullable Context context) {
        super(context, databasename, null, 33);
    }



    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS customers (CustID integer primary key autoincrement ," +
                " Username text not null , CustName text not null, Password text not null , " +
                "cnf_pass text not null, Gender text not null , Birthdate text , Job text not null)");

        sqLiteDatabase.execSQL("create table Orders (OrdID integer primary key autoincrement , " +
                "CustOID integer ,OrdDate date ,Address text not null , " +
                "foreign key (CustOID) REFERENCES customers(CustID))");

/*        sqLiteDatabase.execSQL("create table Order_Details(Ordetails_ID integer primary key autoincrement ," +
                        "Quantity integer," +
                 "foreign key (Ord_ID) REFERENCES Orders(OrdID), " +
                " foreign key (Pro_ID) REFERENCES Products(ProID))"); */

        sqLiteDatabase.execSQL("create table Products (ProID integer primary key autoincrement , ProName text not null , " +
                "Price integer , Quantity integer , Cat_ID integer, Barcode text , foreign key (Cat_ID) REFERENCES category(catid))");

        sqLiteDatabase.execSQL("create table category (catid integer primary key autoincrement , catname text not null)");

        sqLiteDatabase.execSQL("create table ShoppingCart (cartid integer primary key autoincrement ," +
                "proname text not null, proprice integer, proquantity integer, cartquantity integer)");

        addCategory(sqLiteDatabase);
        addProduct(sqLiteDatabase);

    }

    @Override

    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS customers" + TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS Orders");
      //  sqLiteDatabase.execSQL("DROP TABLE IF EXISTS Order_Details");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS Products");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS category");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS ShoppingCart");
        onCreate(sqLiteDatabase);
    }

    public long addUser(String user, String custname, String password, String cnf_pass, String gender, long birthdate, String job)
    {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Username", user);
        contentValues.put("CustName", custname);
        contentValues.put("Password", password);
        contentValues.put("cnf_pass", cnf_pass);
        contentValues.put("Gender", gender);
        contentValues.put("Birthdate", birthdate);
        contentValues.put("Job", job);
        long res = db.insert("customers", null, contentValues);
        //  db.close();
        return res;
    }
    public void updatePassword(String username,String password)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues values= new ContentValues();
        values.put("Password",password);
        db.update("customers",values,
                "Username"+ "=?", new String[] {username});
        //db.close();
    }

    public Cursor checkUser() {

        SQLiteDatabase db = getReadableDatabase();
        String[] rowDetails = {"Username", "Password"};
        Cursor cursor = db.query("customers", rowDetails, null, null, null, null, null);
        if (cursor != null) {
            cursor.moveToNext();
        }

        return cursor;
    }
    // ProID, ProName, Price,Quantity, Cat_ID
    public void addProduct(SQLiteDatabase sqLiteDatabase)
    {


        ContentValues contentValues = new ContentValues();
        contentValues.put("ProName", "Lipstick");
        contentValues.put("Price", 10);
        contentValues.put("Quantity", 6);
        contentValues.put("Cat_ID", 1);
        contentValues.put("Barcode","036000291452");
        sqLiteDatabase.insert("Products", null, contentValues);


        ContentValues contentValues1 = new ContentValues();
        contentValues1.put("ProName", "Eyeshadow");
        contentValues1.put("Price", 11);
        contentValues1.put("Quantity", 5);
        contentValues1.put("Cat_ID", 1);
        contentValues1.put("Barcode","8992772485012");

       sqLiteDatabase.insert("Products", null, contentValues1);


        ContentValues contentValues2 = new ContentValues();
        contentValues2.put("ProName", "Powder");
        contentValues2.put("Price", 20);
        contentValues2.put("Quantity", 7);
        contentValues2.put("Cat_ID", 1);
        contentValues2.put("Barcode","725272730706");
        sqLiteDatabase.insert("Products", null, contentValues2);


        ContentValues contentValues3 = new ContentValues();
        contentValues3.put("ProName", "Nailpolish");
        contentValues3.put("Price", 3);
        contentValues3.put("Quantity", 9);
        contentValues3.put("Cat_ID", 1);
        contentValues2.put("Barcode","129002702047");
        sqLiteDatabase.insert("Products", null, contentValues3);


        ContentValues contentValues4 = new ContentValues();
        contentValues4.put("ProName", "Foundation");
        contentValues4.put("Price", 60);
        contentValues4.put("Quantity", 7);
        contentValues4.put("Cat_ID", 1);
        contentValues4.put("Barcode","12");
        sqLiteDatabase.insert("Products", null, contentValues4);

        ContentValues contentValues5 = new ContentValues();
        contentValues5.put("ProName", "Concealer");
        contentValues5.put("Price", 200);
        contentValues5.put("Quantity", 90);
        contentValues5.put("Cat_ID", 1);
        contentValues5.put("Barcode","12");

        sqLiteDatabase.insert("Products", null, contentValues5);


        ContentValues contentValues6 = new ContentValues();
        contentValues6.put("ProName", "Highlighter");
        contentValues6.put("Price", 350);
        contentValues6.put("Quantity", 8);
        contentValues6.put("Cat_ID", 1);
        contentValues6.put("Barcode","12");

        sqLiteDatabase.insert("Products", null, contentValues6);


        /////
        ContentValues contentValues8 = new ContentValues();
        contentValues8.put("ProName", "skirt");
        contentValues8.put("Price", 60);
        contentValues8.put("Quantity", 2);
        contentValues8.put("Cat_ID", 2);
        contentValues8.put("Barcode","12");

        sqLiteDatabase.insert("Products", null, contentValues8);

        ContentValues contentValues9 = new ContentValues();
        contentValues9.put("ProName", "sweatpants");
        contentValues9.put("Price", 50);
        contentValues9.put("Quantity", 4);
        contentValues9.put("Cat_ID", 2);
        contentValues9.put("Barcode","12");

        sqLiteDatabase.insert("Products", null, contentValues9);

        //////

        ContentValues contentValues7 = new ContentValues();
        contentValues7.put("ProName", "The best of me book");
        contentValues7.put("Price", 30);
        contentValues7.put("Quantity", 3);
        contentValues7.put("Cat_ID", 3);
        contentValues7.put("Barcode","12");

        sqLiteDatabase.insert("Products", null, contentValues7);




    }

    public void addCategory(SQLiteDatabase sqLiteDatabase)
    {

//        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("catname", "cosmetics");
        sqLiteDatabase.insert("category", null, contentValues);

        ContentValues contentValues1 = new ContentValues();
        contentValues1.put("catname", "clothes");
        sqLiteDatabase.insert("category", null, contentValues1);

        ContentValues contentValues2 = new ContentValues();
        contentValues2.put("catname", "books");
        sqLiteDatabase.insert("category", null, contentValues2);


    }

    public Cursor fetchCat() {

        SQLiteDatabase db = getReadableDatabase();
        String [] rowdetails = {" catid","catname"};
        Cursor cursor = db.query("category" ,rowdetails , null , null , null , null , null );

       // Cursor cursor = db.rawQuery("select * from category " , null);
        if (cursor !=null) {
            cursor.moveToFirst();
        }

        return cursor;
    }



    public Cursor fetchProduct(int catid) {

        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("select ProName ,Price , Quantity from  " +
                "Products where  Cat_ID ='" + catid+"'" , null);


        if (cursor.getCount() > 0) {
            cursor.moveToNext();
        }

        return cursor;
    }



    public Cursor fetchallProduct() {

        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from Products" , null);


        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
        }

        return cursor;
    }



    public Cursor fetchaddedquant(String prodname) {

        SQLiteDatabase db = getReadableDatabase();
        String[]arg = {prodname};
        //?
        Cursor cursor = db.rawQuery("select  proquantity from ShoppingCart where proname like ?" , arg);


        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
        }
        db.close();

        return cursor;
    }
    // sqLiteDatabase.execSQL("create table ShoppingCart (cartid integer primary key autoincrement ," +
    //                "proname text not null, proprice integer, proquantity integer, cartquantity integer)");



    public Cursor getProduct(String ProductName, int categoryid)
    {
        SQLiteDatabase db=getReadableDatabase();

        String [] args= new String[]{"%" + ProductName+ "%",String.valueOf(categoryid)} ;
        //Cursor cursor=db.rawQuery("select ProName ,Price , Quantity from  Products where ProName like ?  ",args);
        Cursor cursor=db.rawQuery("select ProName ,Price , Quantity from  Products where ProName like ? and Cat_ID = ?",args);

        if(cursor!=null)
        {
            cursor.moveToFirst();
        }

        return cursor;


    }

    public Cursor getBarCode(String barcode, int categoryid)
    {
        SQLiteDatabase db=getReadableDatabase();

        String [] args= new String[]{"%" + barcode+ "%",String.valueOf(categoryid)} ;

        Cursor cursor=db.rawQuery("select ProName ,Price , Quantity from  Products where Barcode like ? and Cat_ID = ?",args);

        if(cursor!=null)
        {
            cursor.moveToFirst();
        }

        return cursor;


    }



    //mlhash lzma
    public Cursor checkProduct(String ProductName)
    {
        SQLiteDatabase db=getReadableDatabase();

        String [] args= new String[]{"%" + ProductName+ "%"} ;

        Cursor cursor=db.rawQuery("select ProName from  Products where ProName like ?",args);

        if(cursor!=null)
        {
            cursor.moveToFirst();
        }

        return cursor;


    }

    public void updateQuantity(String productname, int newproductquantity)
    {
         SQLiteDatabase db=getWritableDatabase();
         ContentValues cv= new ContentValues();
         cv.put("Quantity", String.valueOf(newproductquantity));
        // db.update("Products", cv ,"ProName=" + productname,null);
        //db.update("Products", cv, "where ProName ="+ productname, null);

        //String strSQL = "UPDATE Products SET Quantity = newproductquantity WHERE ProName = "+ productname;
        //db.execSQL(strSQL);

        db.update("Products" , cv, "ProName = ?", new String[] {productname});

    }


    public void addToShoppingCart(String name, int price, int quantity, int cartQuantity)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues values= new ContentValues();
        values.put("proname",name);
        values.put("proprice",price);
        values.put("proquantity",quantity);
        values.put("cartquantity", cartQuantity);

       db.insert("ShoppingCart" ,null ,values);
       db.close();

    }


    public Cursor fetchShoppingCart() {

        SQLiteDatabase db = getReadableDatabase();
       // Cursor cursor = db.rawQuery("select * from ShoppingCart",null);
        //

        String[] rowDetails = {"proname", "proprice", "proquantity", "cartquantity"};
        Cursor cursor = db.query("ShoppingCart", rowDetails, null,
                null, null, null, null);

        if(cursor!=null) {
            cursor.moveToNext();
        }

        return cursor;
    }

    //get product prices of shoppping cart no where
    public Cursor checkTotal()
    {

        SQLiteDatabase db = getReadableDatabase();
        String[] rowDetails = {"proprice"};
        Cursor cursor = db.query("ShoppingCart", rowDetails, null,
                null, null, null, null);

        if(cursor!=null) {
            cursor.moveToNext();
        }

        return cursor;

    }


    //update quantity in cart
     public void updateCartQuantity(String Name, Integer Quantity)
    {
        SQLiteDatabase db=getWritableDatabase();
        ContentValues cv= new ContentValues();
        cv.put("proquantity", String.valueOf(Quantity));
        db.update("ShoppingCart" , cv, "proname = ?", new String[] {Name});

    }



    public Cursor getProductID(String name)
    {
        SQLiteDatabase db=getReadableDatabase();

        String [] args= new String[]{"%" + name+ "%"} ;

        Cursor cursor=db.rawQuery("select ProID, ProName,Price,Quantity  from Products where ProName like ?",args);

        if(cursor!=null)
        {
            cursor.moveToFirst();
        }

        return cursor;

    }


    public void deleteitem(String name)
    {
        SQLiteDatabase db=getWritableDatabase();
        db.delete("ShoppingCart" ,"proname='" + name + "'" ,null);
    }

    public void releaseShoppingCartRows()
    {
        SQLiteDatabase db=getWritableDatabase();
        db.rawQuery("  DELETE FROM ShoppingCart" , null);

    }

   /* public void updatePrice(Integer price)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues vals= new ContentValues();
        vals.put("price", price);
        db.update("")

    } */

}
