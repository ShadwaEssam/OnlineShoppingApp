package com.example.se_commerce;

public class Order {


    int id ;
    String Date ;
    String Address ;


    public  Order()
    {

    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date= date;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address= address;
    }
}
