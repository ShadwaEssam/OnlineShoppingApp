package com.example.se_commerce;
import android.content.Intent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;

import android.content.Context;

import android.view.LayoutInflater;

import android.view.ViewGroup;

import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class CustomAdapter extends ArrayAdapter<Product> implements View.OnClickListener{

    private ArrayList<Product> dataSet;
    Context mContext;
    HashMap<String,Integer> productDic;
    Product p = new Product();

    // View lookup cache
    private static class ViewHolder {
        public View info;
        TextView txtName;
        TextView txtPrice;
        TextView txtQuantity;
        TextView txtCartNum;
        Button addToCart;
        ImageView addButton;
        ImageView removeButton;

    }

    public CustomAdapter(ArrayList<Product> data, Context context, HashMap<String,Integer> productDic) {
        super(context, R.layout.content_main, data);
        this.dataSet = data;
        this.mContext=context;
        this.productDic = productDic;
    }


    @Override
    public void onClick(View v) {

        int position=(Integer) v.getTag();
        Object object= getItem(position);
        Product dataModel=(Product) object;
    }

    private int lastPosition = -1;

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        final Product dataModel = getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view
       final ViewHolder viewHolder; // view lookup cache stored in tag

        final View result;

        if (convertView == null) {
            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.content_main, parent, false);
            viewHolder.txtName = convertView.findViewById(R.id.cname);
            viewHolder.txtPrice = convertView.findViewById(R.id.cprice);
            viewHolder.txtQuantity =convertView.findViewById(R.id.cquantity);
            viewHolder.txtCartNum= convertView.findViewById(R.id.cquantitynum);
            viewHolder.addToCart=convertView.findViewById(R.id.addtocartBtn);
            viewHolder.addButton = convertView.findViewById(R.id.addProductIMG);
            viewHolder.removeButton = convertView.findViewById(R.id.removeProductIMG);
            //
            //dictionary for picked products
            final HashMap<String, Integer > PickedproductDic=new HashMap<String, Integer>();

// +
            viewHolder.addButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    //check if added items exist in ProductDic
                    int productQuantity =  productDic.get(dataModel.Name);   //dict.get(productName) = productQuantity;
                    String productName  =  dataModel.Name;
                    int pickedQuantity=0;
                    if(productQuantity > 0)
                    {
                        //dec quan from hashmap
                        int newproductquantity = productQuantity - 1;
                        productDic.put(productName, newproductquantity);

                        //Update pickedproducts in cart
                        //  pq =5             //5-1 = 4         //4 npq     // get 1 .. pq-npq


                        //fn call to db edit quan VERY IMPORTANTTTT DB UPDATE!!!!!
                       // ProductsActivity.call_db(productName, newproductquantity);

                        //increment and put
                      final String quantityStr=viewHolder.txtCartNum.getText().toString();
                      pickedQuantity= Integer.parseInt(quantityStr);
                      pickedQuantity+=1;
                      p.cartQuantity=pickedQuantity;

                        viewHolder.txtCartNum.setText(String.valueOf(p.cartQuantity)); //Update View.
                        dataModel.setCartQuantity(pickedQuantity);

                        //upd in shoppcart dic
                        //and put TRIAL hnkhleha f addtocrt btn
                       // PickedproductDic.put(productName, p.cartQuantity);
                    }
                    else
                        Toast.makeText(mContext, "There is no items! Quantity Sold", Toast.LENGTH_LONG).show();
                }
            });

            viewHolder.removeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String productName  =  dataModel.Name;

                    int productQuantity =  productDic.get(productName);         //dict.get(productName) = productQuantity;  //Real Count


                    final String quantoMinus=viewHolder.txtCartNum.getText().toString();
                    int pickedQuantity=Integer.parseInt(quantoMinus);


                    if(pickedQuantity > 0)
                    {
                        //dec quan from hashmap
                        int newproductquantity = productQuantity + 1;
                        productDic.put(productName, newproductquantity);

                        //fn call to db edit quan VERY IMPORTANTTTT DB UPDATE!!!!!
                        //ProductsActivity.call_db(productName, newproductquantity);

                        // decrement

                        pickedQuantity-=1;
                        p.cartQuantity=pickedQuantity;

                        viewHolder.txtCartNum.setText(String.valueOf(p.cartQuantity)); //Update View.
                        dataModel.setCartQuantity(pickedQuantity);

                        //upd in shoppcart dic

                        //and put TRIAL hnkhleha f addtocrt btn
                       // PickedproductDic.put(productName, p.cartQuantity);

                    }
                    else
                        Toast.makeText(mContext, "This item is no longer in your cart", Toast.LENGTH_LONG).show();
                }
            });

                 // add to cart btn
            viewHolder.addToCart.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Toast.makeText(getContext() , "Added to Cart" , Toast.LENGTH_SHORT).show();

                     //yro7 ll datbase y insert f table shopping cart productname, product price, productquantity
                    String productName  =  dataModel.getName();
                    int productPrice  =  dataModel.getPrice();
                    int productQuantity  =  dataModel.getQuantity();
                    int cartQuantity = dataModel.getCartQuantity();
                    ProductsActivity.call_db_cart(productName, productPrice, productQuantity, cartQuantity);


                }
            });

            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Snackbar.make(v, dataModel.getName() + "\n"+" Price: "+ dataModel.getPrice() +" Quantity: "+dataModel.getQuantity(), Snackbar.LENGTH_LONG)
                            .setAction("No action", null).show();
                }
            });

            result=convertView;
            convertView.setTag(viewHolder);
        }
        else {
            viewHolder = (ViewHolder) convertView.getTag();
            result=convertView;
        }

        Animation animation = AnimationUtils.loadAnimation(mContext, (position > lastPosition) ? R.anim.up_from_bottom : R.anim.down_from_top);
        result.startAnimation(animation);
        lastPosition = position;

        viewHolder.txtName.setText(dataModel.getName());
        viewHolder.txtPrice.setText(String.valueOf(dataModel.getPrice()));
        viewHolder.txtQuantity.setText(String.valueOf(dataModel.getQuantity()));
        viewHolder.txtCartNum.setText(String.valueOf(dataModel.getCartQuantity()));

        //viewHolder.info.setOnClickListener(this);
        //viewHolder.info.setTag(position);
        // Return the completed view to render on screen
        return convertView;
    }
}