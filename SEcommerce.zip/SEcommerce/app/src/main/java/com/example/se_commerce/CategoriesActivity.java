package com.example.se_commerce;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class CategoriesActivity extends AppCompatActivity {

    ListView catview;
    ArrayAdapter<String> catadap;
    DatabaseHelper db;
    List<Category> categories;
    Button logout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categories);

        catview =(ListView)findViewById(R.id.catt);
        catadap = new ArrayAdapter<String>(this , android.R.layout.simple_list_item_1);
        db = new DatabaseHelper(this);


        catview.setAdapter(catadap);
        Cursor cursor = db.fetchCat();
        categories = new ArrayList<>();

        while (!cursor.isAfterLast())
        {
            Category category = new Category( Integer.parseInt(cursor.getString(0)), cursor.getString(1));

            catadap.add(category.Name); //cosmetics -> 0
            categories.add(category);//cosmetics -> 0

            cursor.moveToNext();
        }

        catview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                                      @Override
                                                      public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

              Intent i= new Intent(CategoriesActivity.this, ProductsActivity.class);
              i.putExtra("category_id", categories.get(position).id);
              startActivity(i);
              }
          }
        );


        logout= (Button)findViewById(R.id.logoutBtn);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SharedPreferences preferences = getSharedPreferences("checkbox", MODE_PRIVATE);
                SharedPreferences.Editor editor=preferences.edit();
                editor.putString("remember","false");
                editor.apply();
                Toast.makeText(CategoriesActivity.this,"We'll miss you!", Toast.LENGTH_SHORT).show();
                finish();

            }
        });




    }
}
