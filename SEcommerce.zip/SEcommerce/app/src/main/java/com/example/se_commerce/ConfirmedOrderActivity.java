package com.example.se_commerce;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ConfirmedOrderActivity extends AppCompatActivity {
    Button gps;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmed_order);

        gps= findViewById(R.id.gpsBtn);



        gps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i= new Intent(ConfirmedOrderActivity.this, MapsActivity.class);
                startActivity(i);
            }
        });
    }
}
