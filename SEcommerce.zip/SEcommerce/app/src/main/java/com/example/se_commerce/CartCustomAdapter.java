package com.example.se_commerce;
        import android.content.Intent;
        import android.database.Cursor;
        import android.view.View;
        import android.view.animation.Animation;
        import android.view.animation.AnimationUtils;
        import android.widget.ArrayAdapter;

        import android.content.Context;

        import android.view.LayoutInflater;

        import android.view.ViewGroup;

        import android.widget.Button;
        import android.widget.ImageView;
        import android.widget.TextView;
        import android.widget.Toast;

        import androidx.annotation.Nullable;

        import com.google.android.material.snackbar.Snackbar;

        import java.util.ArrayList;
        import java.util.HashMap;
        import java.util.List;


public class CartCustomAdapter extends ArrayAdapter<Product> implements View.OnClickListener{
    DatabaseHelper db;
    private ArrayList<Product> dataSet;
    Context mContext;
    HashMap<String,Integer> productDic;
    Product p = new Product();

    // View lookup cache
    private static class ViewHolder {
        public View info;
        TextView txtName;
        TextView txtPrice;
        TextView txtQuantity;
        TextView txtCartNum;
        ImageView delBtn;
        ImageView addButton;
        ImageView removeButton;
      //  Button proceedBtn;
    }
    public CartCustomAdapter(ArrayList<Product> data, Context context) {
        super(context, R.layout.cart_content_main, data);
        this.dataSet = data;
        this.mContext=context;
       // this.productDic = productDic;
    }


    @Override
    public void onClick(View v) {

        int position=(Integer) v.getTag();
        Object object= getItem(position);
        Product dataModel=(Product) object;
    }

    private int lastPosition = -1;
    int quant;

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        final Product dataModel = this.dataSet.get(position);
        //dina are u here?
        // Check if an existing view is being reused, otherwise inflate the view
        final ViewHolder viewHolder; // view lookup cache stored in tag

        final View result;

        if (convertView == null) {
            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.cart_content_main, parent, false);
            viewHolder.txtName = convertView.findViewById(R.id.cname);
            viewHolder.txtPrice = convertView.findViewById(R.id.cprice);
            viewHolder.txtQuantity =convertView.findViewById(R.id.cquantity);
            viewHolder.txtCartNum= convertView.findViewById(R.id.cquantitynum);
            viewHolder.addButton = convertView.findViewById(R.id.addProductIMG);
            viewHolder.removeButton = convertView.findViewById(R.id.removeProductIMG);
            viewHolder.delBtn= convertView.findViewById(R.id.deleteproductImg);

            db = new DatabaseHelper(convertView.getContext());
            //viewHolder.proceedBtn= convertView.findViewById(R.id.proceedBtn);



            viewHolder.addButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                        final String quantityStr=viewHolder.txtCartNum.getText().toString();
                        int addedVal= Integer.parseInt(quantityStr);
                        if(addedVal>=0)
                        {
                        addedVal+=1;
                        p.cartQuantity=addedVal;
                        viewHolder.txtCartNum.setText(String.valueOf(p.cartQuantity)); //Update View.
                        dataModel.setCartQuantity(p.cartQuantity);

                       // dataModel.setPrice(p.price);  //new
                        //call db shopping cart and update quantity.. inc quantity
                            //ShoppingCartActivity.fetch_again();
                            Cursor cursor = db.fetchallProduct();
                            while (!cursor.isAfterLast()){
                                quant = cursor.getInt(3);
                                cursor.moveToNext();
                            }

                            quant-=addedVal;
                            dataModel.setQuantity(quant);

                            // get old quantity

                            ShoppingCartActivity.call_to_updateCartQuantity(dataModel.getName(),dataModel.getCartQuantity());
                           // ShoppingCartActivity.putPrice(dataModel.getName(),dataModel.getPrice());
                        }


                        else
                            Toast.makeText(mContext, "This item is no longer in your cart", Toast.LENGTH_LONG).show();


                }
            });

            //todoo
            viewHolder.removeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    final String quantityStr=viewHolder.txtCartNum.getText().toString();
                    int addedVal= Integer.parseInt(quantityStr);

                    if(addedVal>0) {
                        addedVal -= 1;
                        p.cartQuantity = addedVal;

                        Cursor cursor = db.fetchallProduct();
                        while (!cursor.isAfterLast()){
                            quant = cursor.getInt(3);
                            cursor.moveToNext();
                        }
                        quant+=addedVal;
                        dataModel.setQuantity(quant);

                        viewHolder.txtCartNum.setText(String.valueOf(p.cartQuantity)); //Update View.
                        dataModel.setCartQuantity(p.cartQuantity);
                        //call db shopping cart and update quantity.. dec quantity
                        ShoppingCartActivity.call_to_updateCartQuantity(dataModel.getName(),dataModel.getCartQuantity());
                    }
                    else if(addedVal==0)
                    {
                        ShoppingCartActivity.call_to_del(dataModel.getName());
                        dataSet.remove(position);
                        notifyDataSetChanged();
                        //call sc and update quantity.. dec quantity
                        ShoppingCartActivity.call_to_del(dataModel.getName());


                    }
                    else
                        Toast.makeText(mContext, "This item is no longer in your cart", Toast.LENGTH_LONG).show();

                }
            });

            viewHolder.delBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                   // ShoppingCartActivity.call_to_del(dataModel.getName());
                    dataSet.remove(position);
                    notifyDataSetChanged();
                    //call sc and update quantity.. dec quantity
                    ShoppingCartActivity.call_to_del(dataModel.getName());

                }
            });


            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Snackbar.make(v, dataModel.getName() + "\n"+" Price: "+ dataModel.getPrice() +" Quantity: "+dataModel.getQuantity(), Snackbar.LENGTH_LONG)
                            .setAction("No action", null).show();
                }
            });

            result=convertView;
            convertView.setTag(viewHolder);
        }
        else {
            viewHolder = (ViewHolder) convertView.getTag();
            result=convertView;
        }

        Animation animation = AnimationUtils.loadAnimation(mContext, (position > lastPosition) ? R.anim.up_from_bottom : R.anim.down_from_top);
        result.startAnimation(animation);
        lastPosition = position;

        viewHolder.txtName.setText(dataModel.getName());
        viewHolder.txtPrice.setText(String.valueOf(dataModel.getPrice()));
        viewHolder.txtQuantity.setText(String.valueOf(dataModel.getQuantity()));
        viewHolder.txtCartNum.setText(String.valueOf(dataModel.getCartQuantity()));

        //viewHolder.info.setOnClickListener(this);
        //viewHolder.info.setTag(position);
        // Return the completed view to render on screen
        return convertView;
    }
}