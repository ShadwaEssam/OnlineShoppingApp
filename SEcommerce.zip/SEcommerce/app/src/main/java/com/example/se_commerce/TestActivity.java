package com.example.se_commerce;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class TestActivity extends AppCompatActivity {

    ListView catitems;
    ArrayAdapter<String> catitemsadap;
    DatabaseHelper db;
    Product products;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);

        catitems =(ListView)findViewById(R.id.catitemsview);
        catitemsadap = new ArrayAdapter<String>(this , android.R.layout.simple_list_item_1);
        db = new DatabaseHelper(this);

        catitems.setAdapter(catitemsadap);

        int id = products.getId();
        Cursor cursor = db.fetchProduct(id);
        while (!cursor.isAfterLast())
        {
            catitemsadap.add(cursor.getString(0));
            cursor.moveToNext();
        }
    }
}
