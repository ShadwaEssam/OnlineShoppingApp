package com.example.se_commerce;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ShoppingCartActivity extends AppCompatActivity {

    private static DatabaseHelper db;
    TextView name;
    TextView price;
    TextView quantity;
    TextView cartquantity;
    Button proceedbtn;
   // DatabaseHelper db;
    Product product;
    private CartCustomAdapter adp;
    ArrayList<Product> dataModels;
    ArrayList<Product> cartModels;
    String pname;
    int pprice;
    int pquantity;
    int cartQuantity;
    String prodname;
    ListView shoppingCartListView;
    int quant;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_cart);

         name= findViewById(R.id.cname);
         price= findViewById(R.id.cprice);
         quantity= findViewById(R.id.cquantity);
         cartquantity= findViewById(R.id.cquantitynum);
         proceedbtn=findViewById(R.id.proceedBtn);
         db= new DatabaseHelper(getApplicationContext());
         product = new Product();
         shoppingCartListView=findViewById(R.id.searchlist);
        dataModels= new ArrayList<>();
        cartModels= new ArrayList<>();

        Cursor cursor= db.fetchShoppingCart();

        if(cursor.getCount()>0) {
            do {

                product = new Product();
                // shoppingCartListView.setAdapter(null);
                 pname= cursor.getString(0);
                pprice = cursor.getInt(1);
                pquantity = cursor.getInt(2);
                cartQuantity = cursor.getInt(3);
                product.setName(pname);
                product.setPrice(pprice);
                product.setQuantity(pquantity);
                product.setCartQuantity(cartQuantity);
                dataModels.add(product);
                cursor.moveToNext();

            }
            while (!cursor.isAfterLast());

        }

        adp= new CartCustomAdapter(dataModels,getApplicationContext());
        shoppingCartListView.setAdapter(adp);
        shoppingCartListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                prodname = shoppingCartListView.getItemAtPosition(position).toString();
            }
        });


        proceedbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ShoppingCartActivity.this , OrderActivity.class);
                i.putExtra("prodname" , prodname);
                startActivity(i);

            }
        });



    }

    @Override
    protected void onRestart() {

        super.onRestart();
        name= findViewById(R.id.cname);
        price= findViewById(R.id.cprice);
        quantity= findViewById(R.id.cquantity);
        cartquantity= findViewById(R.id.cquantitynum);
        proceedbtn=findViewById(R.id.proceedBtn);
        db= new DatabaseHelper(getApplicationContext());
        product = new Product();
        shoppingCartListView=findViewById(R.id.searchlist);
        dataModels= new ArrayList<>();
        cartModels= new ArrayList<>();

        Cursor cursor= db.fetchShoppingCart();

        do {

            product = new Product();
            shoppingCartListView.setAdapter(null);
            pname= cursor.getString(0);
            pprice= cursor.getInt(1);
            pquantity=cursor.getInt(2);
            cartQuantity = cursor.getInt(3);
            product.setName(pname);
            product.setPrice(pprice);
            product.setQuantity(pquantity);
            product.setCartQuantity(cartQuantity);
            dataModels.add(product);
            cursor.moveToNext();

        }
        while (!cursor.isAfterLast());

        adp= new CartCustomAdapter(dataModels,getApplicationContext());
        shoppingCartListView.setAdapter(adp);

    }

     public static void call_to_del(String name)
     {
         db.deleteitem(name);

     }


     public static  void call_to_updateCartQuantity(String name, Integer cartQuantity)
     {
         db.updateCartQuantity(name,cartQuantity);

     }

//not used

  /*  public static void fetch_again()
    {

        Cursor cursor=  db.fetchallProduct();
        while (!cursor.isAfterLast())
        {
             quant = cursor.getInt(3);
            cursor.moveToNext();
        }

    }
    */
}
