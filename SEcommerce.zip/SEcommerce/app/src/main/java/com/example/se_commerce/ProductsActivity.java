package com.example.se_commerce;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;

import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class ProductsActivity extends AppCompatActivity {
    private static final int REQUEST_CODE_SPEECH_INPUT =1000 ;

    static DatabaseHelper db ;
    Product product;
    Button searchButton;
    TextView searchTextView;
    ArrayList<Product> dataModels; //*
    ListView listView;
    private CustomAdapter adapter;
    ImageView addProductImage;
    ImageView removeProductImage;
    Button voiceBTN;
    static TextView searchEditText;
    Button CamBtn;

    Button AddToCart;
    Button showCartbtn;

    //



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_products);

        searchButton=findViewById(R.id.searchBtn);
        searchTextView= findViewById(R.id.searchEditText);
        db= new DatabaseHelper(this);
        product = new Product();
        addProductImage= findViewById(R.id.addProductIMG);
        removeProductImage= findViewById(R.id.removeProductIMG);
        AddToCart =findViewById(R.id.addtocartBtn);
        showCartbtn= findViewById(R.id.showcartBtn);
        voiceBTN=findViewById(R.id.voiceBtn);
         searchEditText=findViewById(R.id.searchEditText);
        CamBtn= findViewById(R.id.camBtn);





        CamBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ProductsActivity.this,MyCameraScanner.class);
                startActivity(i);
            }
        });



        //finding listview
        final int category_id = getIntent().getIntExtra("category_id", -1);
        db = new DatabaseHelper(getApplicationContext());
        listView = findViewById(R.id.mylist);
        dataModels= new ArrayList<>();
        String s=getIntent().getStringExtra("stt");
        searchTextView.setText(s);


        //dictionary to keep track of quantity
        final Cursor c= db.fetchProduct(category_id);
        final HashMap<String, Integer > productDic=new HashMap<String, Integer>();
        while(!c.isAfterLast()) {

            String productName = c.getString(0);
            int productQuantity = c.getInt(2);
            productDic.put(productName,productQuantity);
            c.moveToNext();
        }
        //dic productDic is full of available items
        // fn

        final Cursor cursor= db.fetchProduct(category_id);
        while(!cursor.isAfterLast()) {
            Product product = new Product();
            product.setName(cursor.getString(0));
            product.setPrice(cursor.getInt(1));
            product.setQuantity(cursor.getInt(2));

            dataModels.add(product);
            cursor.moveToNext();

        }


        adapter= new CustomAdapter(dataModels,getApplicationContext(), productDic);
        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                            @Override
                                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                                                Intent i= new Intent(ProductsActivity.this, ShoppingCartActivity.class);
                                                i.putExtra("product_name", dataModels.get(position).getName());
                                                i.putExtra("product_price", dataModels.get(position).getPrice());
                                                i.putExtra("product_quantity", dataModels.get(position).getQuantity());
                                                i.putExtra("product_cartquantity", dataModels.get(position).getCartQuantity());
                                                startActivity(i);
                                            }
                                        }
        );

        showCartbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ProductsActivity.this,ShoppingCartActivity.class);
                startActivity(i);
            }
        });

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adapter.clear();

                String st = searchTextView.getText().toString();


                if (st.equals("")) {
                    Toast.makeText(getApplicationContext(), "Please enter an item to search for!", Toast.LENGTH_LONG).show();

                }

                else {
                    //name, category 3la asas eno dkhl name f3ln
                    Cursor cursor = db.getProduct(st, category_id);

                    //enma hna hydkhl barcode, category
                    Cursor c1= db.getBarCode(st,category_id);

                    if (cursor.getCount() == 0 && c1.getCount() ==0)  {
                        Toast.makeText(getApplicationContext(), "couldn't find this item", Toast.LENGTH_LONG).show();
                    }


                    else if(c1.getCount()!=0)
                    {

                        do {

                            String name = c1.getString(0);
                            int price = c1.getInt(1);
                            int quantity = c1.getInt(2);
                            product.setName(name);
                            product.setPrice(price);
                            product.setQuantity(quantity);
                            adapter.add(product);


                        }
                        while (cursor.moveToNext());

                    }


                    else if (c.getCount()!=0){

                        do {

                            String name = cursor.getString(0);
                            int price = cursor.getInt(1);
                            int quantity = cursor.getInt(2);
                            product.setName(name);
                            product.setPrice(price);
                            product.setQuantity(quantity);
                            adapter.add(product);


                        }
                        while (cursor.moveToNext());
                    }
                }


            }
        });

        voiceBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                speak();
            }

        });

    }

    @Override
    protected void onRestart() {
        super.onRestart();
        //finding listview
        final int category_id = getIntent().getIntExtra("category_id", -1);
        db = new DatabaseHelper(getApplicationContext());
        listView = findViewById(R.id.mylist);
        dataModels= new ArrayList<>();
        String s=getIntent().getStringExtra("stt");
        searchTextView.setText(s);


        //dictionary to keep track of quantity
        final Cursor c= db.fetchProduct(category_id);
        final HashMap<String, Integer > productDic=new HashMap<String, Integer>();
        while(!c.isAfterLast()) {

            String productName = c.getString(0);
            int productQuantity = c.getInt(2);
            productDic.put(productName,productQuantity);
            c.moveToNext();
        }
        //dic productDic is full of available items
        // fn

        final Cursor cursor= db.fetchProduct(category_id);
        while(!cursor.isAfterLast()) {
            Product product = new Product();
            product.setName(cursor.getString(0));
            product.setPrice(cursor.getInt(1));
            product.setQuantity(cursor.getInt(2));

            dataModels.add(product);
            cursor.moveToNext();

        }


        adapter= new CustomAdapter(dataModels,getApplicationContext(), productDic);
        listView.setAdapter(adapter);







    }

    private void speak() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your wanted product");
       //  startActivityForResult(intent, REQUEST_CODE_SPEECH_INPUT);

        try{
           startActivityForResult(intent, REQUEST_CODE_SPEECH_INPUT);
        }

        catch (Exception e)
        {
            Toast.makeText(getApplicationContext() , ""+e.getMessage() , Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case REQUEST_CODE_SPEECH_INPUT: {
                if (resultCode == RESULT_OK && null != data) {
                    //get text array from voice intent
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    searchEditText.setText(result.get(0));
                }
                break;
            }
        }
    }

    public static void call_db_cart(String name, int price, int quantity, int cartQuantity){
        Cursor cursor= db.getProductID(name); //Does product exist?

       // ((cursor != null) && (cursor.getCount() > 0))

/*        if (cursor.moveToFirst()) {

            db.updateCartQuantity(name,quantity);
        }
        else */{
            //
            db.addToShoppingCart(name, price,quantity, cartQuantity);
        }

    }





}
