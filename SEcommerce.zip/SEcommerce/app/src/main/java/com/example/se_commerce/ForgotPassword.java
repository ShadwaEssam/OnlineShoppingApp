package com.example.se_commerce;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ForgotPassword extends AppCompatActivity {
    EditText userEditText;
    EditText passEditText;
    Button resetPassBtn;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgotpassword);

        db= new DatabaseHelper(this);
        userEditText=(EditText)findViewById(R.id.userEditText);
        passEditText=(EditText)findViewById(R.id.passEditText);
        resetPassBtn=(Button)findViewById(R.id.resetpassBtn);

        resetPassBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sameuser= userEditText.getText().toString().trim();
                String newpswd= passEditText.getText().toString().trim();

                db.updatePassword(sameuser,newpswd);
                Toast.makeText(ForgotPassword.this,"Password Changed", Toast.LENGTH_SHORT).show();

                Intent i = new Intent(ForgotPassword.this , CategoriesActivity.class);
                startActivity(i);

            }
        });






    }
}
