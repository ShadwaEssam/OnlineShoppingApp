package com.example.se_commerce;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

EditText usernameEditText;
EditText passwordEditText;
Button loginBotton;
TextView registerTextView;
DatabaseHelper db;

CheckBox remember;
Button forgotpass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db= new DatabaseHelper(this);
        usernameEditText= (EditText)findViewById(R.id.edittext_username);
        passwordEditText=(EditText)findViewById(R.id.edittext_password);
        loginBotton=(Button)findViewById(R.id.button_login);
        registerTextView= (TextView)findViewById(R.id.textview_register);
        remember= (CheckBox)findViewById(R.id.checkBoxRem);
        forgotpass=(Button)findViewById(R.id.forgotpassBtn);

        SharedPreferences preferences= getSharedPreferences("checkbox", MODE_PRIVATE);
        String checkbox=preferences.getString("remember", "");

        if(checkbox.equals("true"))
        {
         Intent intent= new Intent(MainActivity.this, CategoriesActivity.class);
         startActivity(intent);
        }

        else if(checkbox.equals("false"))
        {
            Toast.makeText(getApplicationContext() , "Please Sign In" , Toast.LENGTH_SHORT).show();
        }

        registerTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent registrerIntent = new Intent(MainActivity.this,RegisterActivity.class);
                startActivity(registrerIntent);

            }
        });

        loginBotton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String user= usernameEditText.getText().toString().trim();
                String pswd= passwordEditText.getText().toString().trim();
                Cursor cursor = db.checkUser();

                while (!cursor.isAfterLast())
                {
                    if (cursor.getString(0).equals(user))
                    {
                        if (cursor.getString(1).equals(pswd))
                        {

                            //Intent i = new Intent(MainActivity.this , HomeActivity.class);
                            Intent i = new Intent(MainActivity.this , CategoriesActivity.class);
                            startActivity(i);
                        }
                        else {
                            Toast.makeText(getApplicationContext() , "re-enter the data" , Toast.LENGTH_LONG).show();
                        }
                    }
                    cursor.moveToNext();

                }

            }
       });
            remember.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                    if(buttonView.isChecked())
                    {
                        SharedPreferences preferences = getSharedPreferences("checkbox", MODE_PRIVATE);
                        SharedPreferences.Editor editor=preferences.edit();
                        editor.putString("remember","true");
                        editor.apply();
                        Toast.makeText(MainActivity.this,"Checked", Toast.LENGTH_SHORT).show();

                    }
                    else if (!buttonView.isChecked())
                    {
                        SharedPreferences preferences = getSharedPreferences("checkbox", MODE_PRIVATE);
                        SharedPreferences.Editor editor=preferences.edit();
                        editor.putString("remember","false");
                        editor.apply();
                        Toast.makeText(MainActivity.this,"Unchecked", Toast.LENGTH_SHORT).show();

                    }

                }
            });

        forgotpass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this , ForgotPassword.class);
                startActivity(i);

            }
        });

}


}



