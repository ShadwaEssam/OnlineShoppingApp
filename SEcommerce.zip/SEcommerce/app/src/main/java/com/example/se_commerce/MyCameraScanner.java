package com.example.se_commerce;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;
import org.json.JSONException;
import org.json.JSONObject;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class MyCameraScanner extends AppCompatActivity {
    Button buttonScan;
    TextView textViewCode;
    ImageView imgview;
    private IntentIntegrator qrscan;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_camera_scanner);
        imgview= findViewById(R.id.imageView3);

        buttonScan =  findViewById(R.id.buttonScan);
        textViewCode = findViewById(R.id.textViewName);


        qrscan= new IntentIntegrator(this);
        buttonScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent,0);
               qrscan.initiateScan();
            }
            });

    }
    //working camera
/**
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);

        if (requestCode == 0) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            imgview.setImageBitmap(photo);
        }
    } */

    /*protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);

        if (requestCode == 0) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            imgview.setImageBitmap(photo);

            try {
                //converting the data to json
                JSONObject obj = new JSONObject(result.getContents());
                //setting values to textviews
                textViewCode.setText(obj.getString("@string/zxing_app_name"));
            } catch (JSONException e) {
                e.printStackTrace();
                //if control comes here
                //that means the encoded format not matches
                //in this case you can display whatever data is available on the qrcode
                //to a toast
                Toast.makeText(this, result.getContents(), Toast.LENGTH_LONG).show();
            }
        }

        else
        {
            Toast.makeText(this, "Result Not Found", Toast.LENGTH_LONG).show();

        }
    }
*/

protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
    if (result != null)
    {
        //if qrcode has nothing in it
        if (result.getContents() == null) {
            Toast.makeText(this, "Result Not Found", Toast.LENGTH_LONG).show();
        }

                //if qr contains data
            try {
                //converting the data to json
                JSONObject obj = new JSONObject(result.getContents());
                //setting values to textviews
              //  textViewCode.setText(obj.getString(""));
            }
            catch (JSONException e) {
                e.printStackTrace();
                //if control comes here
                //that means the encoded format not matches
                //in this case you can display whatever data is available on the qrcode
                //to a toast
                Toast.makeText(this, result.getContents(), Toast.LENGTH_LONG).show();
                textViewCode.setText(result.getContents());

                String s= result.getContents();

                Intent i = new Intent(MyCameraScanner.this,ProductsActivity.class);
                i.putExtra("stt",s);
                startActivity(i);




            }
        }
    }

}


//old trial
   /* protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null)
        {
            //if qrcode has nothing in it
            if (result.getContents() == null) {
                Toast.makeText(this, "Result Not Found", Toast.LENGTH_LONG).show();
            }

            else {
                //if qr contains data
                try {
                    //converting the data to json
                    JSONObject obj = new JSONObject(result.getContents());
                    //setting values to textviews
                    textViewCode.setText(obj.getString("@string/zxing_app_name"));
                } catch (JSONException e) {
                    e.printStackTrace();
                    //if control comes here
                    //that means the encoded format not matches
                    //in this case you can display whatever data is available on the qrcode
                    //to a toast
                    Toast.makeText(this, result.getContents(), Toast.LENGTH_LONG).show();
                }
            }
        }

        else {
            super.onActivityResult(requestCode, resultCode, data);
            //
            Bitmap bitmap = (Bitmap)data.getExtras().get("data");
         
            imgview.setImageBitmap(bitmap);

        }
    }

    */

  

