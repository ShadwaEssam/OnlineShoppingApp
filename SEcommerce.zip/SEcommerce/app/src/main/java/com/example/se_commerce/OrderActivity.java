package com.example.se_commerce;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.stream.IntStream;

public class OrderActivity extends AppCompatActivity {
    DatabaseHelper db;
   // ArrayList<Integer> totalPrices;
    int totalprice[];
    TextView gettotal;
    Button submitBtn;
    Product product;
    ArrayList<Product> dataModels;
    int quant;
    int newprice[] ;
    String prodname;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);
        db= new DatabaseHelper(getApplicationContext());
        gettotal= findViewById(R.id.priceTxt);
        totalprice= new int [100];
        submitBtn= findViewById(R.id.submitOrderBtn);
        product = new Product();
        dataModels= new ArrayList<>();
        prodname = getIntent().getStringExtra("prodname");
        newprice=new int[100];
       // product.getName();

       /* Cursor cursor2 = db.fetchaddedquant(prodname);
        while(!cursor2.isAfterLast())
        {
            quant = cursor2.getInt(3);
            cursor2.moveToNext();
        }
 */
        Cursor cursor = db.checkTotal();
        int i=0;
        while(!cursor.isAfterLast())
        {
            totalprice[i]= cursor.getInt(0);
           // totalprice[i] +=totalprice[i];

            cursor.moveToNext();
            i++;
        }

        int cnt=0;

        for (int j=0 ;j<totalprice.length ; j++) {
            cnt = cnt + totalprice[j];
        }



        String st = String.valueOf(cnt);
           gettotal.setText(st);


        //fn call to db edit quan VERY IMPORTANTTTT DB UPDATE!!!!!

        //1- get productname , quantity from shopping cart  lipstick .. 1
        // got vals x, y ... .. x, quantity-1 passed to table products

        //2- send productname, quantity to fn update quantity to upd product table .. lipstick 4-1 = 3
        //bykhod quantity adem y7ot bdalo l gded
        //db.updateQuantity(productName, newproductquantity);

        Cursor cursor1= db.fetchShoppingCart();
        //gets name 0*, price 1, quantity 2*, cartquantity 3
        while (!cursor1.isAfterLast())
        {

            String pname= cursor1.getString(0);
            int pquantity=cursor1.getInt(2);
            product.setName(pname);
            product.setQuantity(pquantity);
            dataModels.add(product);
            cursor1.moveToNext();
        }

        db.updateQuantity(product.getName(),product.getQuantity()-1);

        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(OrderActivity.this , ConfirmedOrderActivity.class);
                startActivity(i);


            }
        });

       db.releaseShoppingCartRows();
       //delete from list view shopping carts


    }
}
