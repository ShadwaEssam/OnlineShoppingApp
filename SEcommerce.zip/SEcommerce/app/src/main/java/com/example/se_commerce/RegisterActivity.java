package com.example.se_commerce;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {
    DatabaseHelper db;
    EditText usernameEditText;
    EditText passwordEditText;
    EditText cnfrmPasswordEditText;
    Button RegisterButton;
    TextView loginTextView;
    TextView genderEditText;
    CalendarView birthdateCV;
    TextView jobEditText;
    TextView customerEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        db= new DatabaseHelper(this);
        usernameEditText= (EditText)findViewById(R.id.edittext_username);
        customerEditText=(EditText)findViewById(R.id.edittext_custname);
        passwordEditText=(EditText)findViewById(R.id.edittext_password);
        cnfrmPasswordEditText=(EditText)findViewById(R.id.edittext_cnf_password);
        genderEditText= (EditText)findViewById(R.id.edittext_gender);
        birthdateCV=(CalendarView)findViewById(R.id.calendarView);
        jobEditText=(EditText)findViewById(R.id.edittext_job);

        RegisterButton =(Button)findViewById(R.id.button_register);
        loginTextView= (TextView)findViewById(R.id.textview_login);

        loginTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent LoginIntent= new Intent(RegisterActivity.this,MainActivity.class);
                startActivity(LoginIntent);
            }
        });

        RegisterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user= usernameEditText.getText().toString().trim();
                String cust=customerEditText.getText().toString().trim();
                String pswd= passwordEditText.getText().toString().trim();
                String cnf_pswd= cnfrmPasswordEditText.getText().toString().trim();
                String gender =genderEditText.getText().toString().trim();
                long birthdate=birthdateCV.getDate();
                String job=jobEditText.getText().toString().trim();

                if(pswd.equals(cnf_pswd))
                {
                    long value= db.addUser(user,cust,pswd,cnf_pswd,gender,birthdate,job);
                    if(value>0)
                    {
                    Toast.makeText(RegisterActivity.this, "Registered Successfully!",Toast.LENGTH_SHORT).show();
                    Intent goToLogin= new Intent(RegisterActivity.this, MainActivity.class);
                    startActivity(goToLogin);
                    }
                    else {
                        Toast.makeText(RegisterActivity.this, "Registered Error",Toast.LENGTH_SHORT).show();
                    }
                }

                else
                {
                    Toast.makeText(RegisterActivity.this, "Password dismatch!",Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}
